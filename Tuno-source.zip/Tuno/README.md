# Tuno 1.0.0

Offline Android guitar tuner and metronome, dark/green design.

- Chromatic microphone tuner with note, frequency, cents and tuning hint.
- Metronome: 30–240 BPM, 2/4, 3/4, 4/4, 6/8; accent on first beat.
- No internet permission or network access.

## Build
Open this directory in Android Studio with JDK 17 and Android SDK 35, then build APK. Or push to GitHub and use GitHub Actions workflow included here. The microphone permission is requested when starting the tuner.

## Notes
This is an initial MVP. Pitch tracking should be tested on real guitar recordings, especially in noisy rooms and low E2. Metronome uses a generated audio click, not sample packs.
