package com.ivanko.tuno;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int GREEN=0xFF46EF93, BG=0xFF090D0B, PANEL=0xFF18221D;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private TextView note, frequency, hint, bpmText, beatText;
    private Button tunerButton, metroButton;
    private volatile boolean tuning=false, metronome=false;
    private volatile int bpm=100, beats=4;
    private AudioRecord recorder;
    private AudioTrack track;
    private Thread tunerThread, metroThread;
    private int beatCounter=0;
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);return t;}
    private Button button(String value){Button b=new Button(this);b.setText(value);b.setAllCaps(false);b.setTextColor(BG);b.setTextSize(16);b.setTypeface(null,Typeface.BOLD);b.setBackground(bg(GREEN,18));return b;}
    private void add(LinearLayout l,View v,int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(height));p.bottomMargin=dp(12);l.addView(v,p);}
    @Override public void onCreate(Bundle saved){super.onCreate(saved);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(22),dp(18),dp(22),dp(14));root.setBackgroundColor(BG);setContentView(root);
        TextView title=text("GUITAR STUDIO",27,GREEN);title.setTypeface(null,Typeface.BOLD);add(root,title,60);
        TextView sub=text("ТЮНЕР  •  МЕТРОНОМ",12,0xFF8AAB98);add(root,sub,26);
        LinearLayout tuner=new LinearLayout(this);tuner.setOrientation(LinearLayout.VERTICAL);tuner.setPadding(dp(12),dp(12),dp(12),dp(12));tuner.setBackground(bg(PANEL,22));add(root,tuner,270);
        add(tuner,text("ХРОМАТИЧЕСКИЙ ТЮНЕР",14,GREEN),30);
        note=text("—",72,Color.WHITE);note.setTypeface(null,Typeface.BOLD);add(tuner,note,90);
        frequency=text("0.0 Hz",20,0xFFB7C7BE);add(tuner,frequency,32);
        hint=text("Нажми «Включить тюнер»",15,0xFFB7C7BE);add(tuner,hint,32);
        tunerButton=button("Включить тюнер");add(root,tunerButton,52);tunerButton.setOnClickListener(v->toggleTuner());
        LinearLayout metro=new LinearLayout(this);metro.setOrientation(LinearLayout.VERTICAL);metro.setPadding(dp(12),dp(10),dp(12),dp(10));metro.setBackground(bg(PANEL,22));add(root,metro,205);
        add(metro,text("МЕТРОНОМ",14,GREEN),25);
        bpmText=text("100 BPM",35,Color.WHITE);bpmText.setTypeface(null,Typeface.BOLD);add(metro,bpmText,50);
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);metro.addView(controls,new LinearLayout.LayoutParams(-1,dp(48)));
        Button minus=button("−");Button plus=button("+");Button signature=button("4/4");
        for(Button b:new Button[]{minus,signature,plus}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(45),1);p.setMargins(dp(3),0,dp(3),0);controls.addView(b,p);}
        minus.setOnClickListener(v->{bpm=Math.max(30,bpm-5);updateTempo();});plus.setOnClickListener(v->{bpm=Math.min(240,bpm+5);updateTempo();});
        signature.setOnClickListener(v->{beats=beats==4?3:beats==3?2:beats==2?6:4;signature.setText(beats+"/"+(beats==6?8:4));});
        beatText=text("● ○ ○ ○",19,GREEN);add(metro,beatText,28);
        metroButton=button("Запустить метроном");add(root,metroButton,52);metroButton.setOnClickListener(v->toggleMetronome());
        TextView foot=text("Стандартный строй: E A D G B E   •   Без интернета",12,0xFF7B9585);add(root,foot,32);
    }
    private void updateTempo(){bpmText.setText(bpm+" BPM");}
    private void toggleTuner(){if(tuning){stopTuner();return;}if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},7);return;}startTuner();}
    @Override public void onRequestPermissionsResult(int req,String[] p,int[] grants){super.onRequestPermissionsResult(req,p,grants);if(req==7&&grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)startTuner();}
    private void startTuner(){tuning=true;tunerButton.setText("Остановить тюнер");tunerThread=new Thread(()->{
        final int rate=44100, n=8192;short[] data=new short[n];int min=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
        try{recorder=new AudioRecord(MediaRecorder.AudioSource.MIC,rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(n*2,min));
            if(recorder.getState()!=AudioRecord.STATE_INITIALIZED)throw new IllegalStateException("Микрофон недоступен");recorder.startRecording();
            while(tuning){int filled=0;while(filled<n&&tuning){int got=recorder.read(data,filled,n-filled);if(got<=0)break;filled+=got;}if(filled<n)continue;
                double hz=detect(data,rate);ui.post(()->showPitch(hz));}
        }catch(Exception e){ui.post(()->hint.setText("Ошибка микрофона: "+e.getMessage()));}finally{if(recorder!=null){try{recorder.stop();}catch(Exception ignored){}recorder.release();recorder=null;}ui.post(()->{tuning=false;tunerButton.setText("Включить тюнер");});}
    },"TunoTuner");tunerThread.start();}
    // Normalized difference autocorrelation: accurate enough for fundamental guitar notes.
    private double detect(short[] a,int rate){int n=a.length;double energy=0;for(short x:a)energy+=x*(double)x;if(Math.sqrt(energy/n)<180)return 0;
        int minLag=rate/1050,maxLag=Math.min(n/2,rate/65);double best=0;int bestLag=-1;
        for(int lag=minLag;lag<=maxLag;lag++){double cross=0,e1=0,e2=0;for(int i=0;i<n-lag;i+=2){double x=a[i],y=a[i+lag];cross+=x*y;e1+=x*x;e2+=y*y;}double corr=cross/Math.sqrt(e1*e2+1);if(corr>0.88&&corr>best){best=corr;bestLag=lag;}}
        if(bestLag<0)return 0;
        // Prefer first strong harmonic-compatible peak to avoid subharmonic octave errors.
        for(int lag=minLag;lag<bestLag;lag++){double cross=0,e1=0,e2=0;for(int i=0;i<n-lag;i+=3){double x=a[i],y=a[i+lag];cross+=x*y;e1+=x*x;e2+=y*y;}if(cross/Math.sqrt(e1*e2+1)>best*0.97){bestLag=lag;break;}}
        return (double)rate/bestLag;
    }
    private void showPitch(double hz){if(!tuning)return;if(hz<65||hz>1050){note.setText("—");frequency.setText("Сыграй струну");hint.setText("Жду звук гитары");return;}
        String[] names={"C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B"};
        double midi=69+12*Math.log(hz/440.0)/Math.log(2);int nearest=(int)Math.round(midi);int cents=(int)Math.round((midi-nearest)*100);
        note.setText(names[((nearest%12)+12)%12]+(nearest/12-1));frequency.setText(String.format(Locale.US,"%.1f Hz   •   %+d центов",hz,cents));
        hint.setText(Math.abs(cents)<=5?"✓ Струна настроена":cents<0?"↑ Подтяни струну":"↓ Ослабь струну");hint.setTextColor(Math.abs(cents)<=5?GREEN:0xFFE9C67A);
    }
    private void stopTuner(){tuning=false;tunerButton.setText("Включить тюнер");}
    private void toggleMetronome(){if(metronome){metronome=false;metroButton.setText("Запустить метроном");return;}metronome=true;metroButton.setText("Остановить метроном");metroThread=new Thread(()->{
        int rate=44100;int size=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
        try{track=new AudioTrack(AudioManager.STREAM_MUSIC,rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(size,rate/5),AudioTrack.MODE_STREAM);track.play();
            long next=System.nanoTime();beatCounter=0;while(metronome){int current=beatCounter++%beats;int count=beats;
                ui.post(()->{StringBuilder s=new StringBuilder();for(int i=0;i<count;i++)s.append(i==current?"● ":"○ ");beatText.setText(s.toString());});
                int len=rate/30;short[] click=new short[len];double hz=current==0?1250:900;for(int i=0;i<len;i++){double envelope=Math.exp(-i/(rate*0.008));click[i]=(short)(Math.sin(2*Math.PI*hz*i/rate)*envelope*18000);}track.write(click,0,click.length);
                next+=60_000_000_000L/bpm;long wait;while(metronome&&(wait=next-System.nanoTime())>0){try{Thread.sleep(Math.min(wait/1_000_000L,20),Math.max(0,(int)(wait%1_000_000L)));}catch(InterruptedException ignored){break;}}
            }
        }catch(Exception ignored){}finally{if(track!=null){try{track.stop();}catch(Exception ignored){}track.release();track=null;}}
    },"TunoMetronome");metroThread.start();}
    @Override protected void onDestroy(){tuning=false;metronome=false;super.onDestroy();}
}
